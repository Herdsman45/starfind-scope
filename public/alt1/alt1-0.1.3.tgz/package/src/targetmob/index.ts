import * as a1lib from "alt1/base";
import * as OCR from "alt1/ocr";
import { webpackImages, ImgRef } from "alt1/base";

var chatfont = require("../fonts/chatbox/12pt.fontmeta.json");

var imgs = webpackImages({
	detectimg: require("./imgs/detectimg.data.png"),
});

export default class TargetMobReader {

	state: { hp: number, name: string } | null = null;
	lastpos: a1lib.PointLike | null = null;
	legacy: boolean = false;

	read(img?: ImgRef) {
		if (!img) { img = a1lib.captureHoldFullRs(); }
		var pos = img.findSubimage(imgs.detectimg);
		if (pos.length != 0) {
			var data = img.toData(pos[0].x - 151, pos[0].y - 16, 220, 46);
			var mobname = OCR.findReadLine(data, chatfont, [[255, 255, 255]], 62, 19, 20, 1);
			var mobhp = OCR.findReadLine(data, chatfont, [[255, 203, 5]], 92, 40, 20, 1);
			this.lastpos = pos[0];
			this.state = {
				name: mobname.text,
				hp: +mobhp.text.replace(/,/g, "")
			};
		} else {
			this.state = null;
		}
		return this.state;
	}
}